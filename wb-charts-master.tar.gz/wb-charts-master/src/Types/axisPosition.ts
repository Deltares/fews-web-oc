export enum AxisPosition {
  AtZero = 'atzero',
  Top = 'top',
  Bottom = 'bottom',
  Left = 'left',
  Right = 'right',
}
